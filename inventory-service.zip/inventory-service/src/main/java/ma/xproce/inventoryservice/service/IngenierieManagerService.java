package ma.xproce.inventoryservice.service;

import ma.xproce.inventoryservice.dao.entities.Ingenierie;
import ma.xproce.inventoryservice.dao.repositeries.IngenierieDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IngenierieManagerService implements IngenierieManager {
    private final IngenierieDAO ingenierieRepo;

    @Autowired
    public IngenierieManagerService(IngenierieDAO ingenierieRepo) {
        this.ingenierieRepo = ingenierieRepo;
    }

    @Override
    public Ingenierie addIngenierie(Ingenierie ingenierie) {
        return ingenierieRepo.save(ingenierie);
    }

    @Override
    public Ingenierie updateIngenierie(Ingenierie ingenierie) {
        return ingenierieRepo.save(ingenierie);
    }

    @Override
    public boolean deleteIngenierie(long id) {
        ingenierieRepo.deleteById(id);
        return true;
    }

    @Override
    public Page<Ingenierie> searchIngenierie(String keyword, int page, int taille) {
        return ingenierieRepo.findByDomaineFormationContains(keyword, PageRequest.of(page, taille));
    }

    @Override
    public List<Ingenierie> getAllIngenieries() {
        return ingenierieRepo.findAll();
    }

    @Override
    public Ingenierie getIngenierieById(long id) {
        return ingenierieRepo.findById(id).orElse(null);
    }
}
