package ma.xproce.inventoryservice.service;

import ma.xproce.inventoryservice.dao.entities.CoutFormation;
import ma.xproce.inventoryservice.dao.repositeries.CoutFormationDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CoutFormationManagerService implements CoutFormationManager {
    private final CoutFormationDAO coutFormationRepo;

    @Autowired
    public CoutFormationManagerService(CoutFormationDAO coutFormationRepo) {
        this.coutFormationRepo = coutFormationRepo;
    }

    @Override
    public CoutFormation addCoutFormation(CoutFormation coutFormation) {
        return coutFormationRepo.save(coutFormation);
    }

    @Override
    public CoutFormation updateCoutFormation(CoutFormation coutFormation) {
        return coutFormationRepo.save(coutFormation);
    }

    @Override
    public boolean deleteCoutFormation(long id) {
        coutFormationRepo.deleteById(id);
        return true;
    }

    @Override
    public Page<CoutFormation> searchCoutFormation(String keyword, int page, int taille) {
        return coutFormationRepo.findByThemeActionContains(keyword, PageRequest.of(page, taille));
    }

    @Override
    public List<CoutFormation> getAllCoutFormation() {
        return coutFormationRepo.findAll();
    }

    @Override
    public CoutFormation getCoutFormationById(long id) {
        return coutFormationRepo.findById(id).orElse(null);
    }
}
