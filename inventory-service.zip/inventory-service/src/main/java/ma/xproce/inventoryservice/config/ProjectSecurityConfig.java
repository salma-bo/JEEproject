package ma.xproce.inventoryservice.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class ProjectSecurityConfig {
    /*<li><a th:href="@{/index}">Home</a></li>
            <li><a th:href="@{/}">Formations</a></li>
            <li><a th:href="@{/ajoutFormation}">Ajouter Formation</a></li>
            <li><a th:href="@{/Ing}">Ingénierie</a></li>
            <li><a th:href="@{/ajoutIngenierie}">Ajouter Ingénierie</a></li>
            <li><a th:href="@{/creator}">Compte</a></li>
            <li><a th:href="@{/sign}">Ajouter des Comptes</a></li>
            <li><a th:href="@{/login}">Se Connecter</a></li>*/
    @Bean
    SecurityFilterChain defaultSecurityFilterChain(HttpSecurity http) throws Exception {
        http.csrf((csrf) -> csrf.disable())
                .authorizeHttpRequests((requests)->requests
                        .requestMatchers("/index","/","/ajoutFormation","/Ing","/ajoutIngenierie","/creator","/sign","/login").authenticated()
                        .requestMatchers("/sign", "/**").permitAll())
                .formLogin((form) -> form
                        //.loginPage("/login")
                        .defaultSuccessUrl("/index", true)
                        .permitAll()
                )
        //.logout((logout) -> logout.logoutSuccessUrl("/login"));
        ;
        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return NoOpPasswordEncoder.getInstance();
    }

}
