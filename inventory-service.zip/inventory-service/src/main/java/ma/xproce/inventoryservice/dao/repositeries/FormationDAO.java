package ma.xproce.inventoryservice.dao.repositeries;

import ma.xproce.inventoryservice.dao.entities.Formation;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FormationDAO extends JpaRepository<Formation,Long> {
    Page<Formation> findByNomFormationContains(String keyword, Pageable pageable);
    public List<Formation> findByNomFormation (String name);

}
