package ma.xproce.inventoryservice.service;

import ma.xproce.inventoryservice.dao.entities.Formation; // Changed from Video to Formation
import ma.xproce.inventoryservice.dao.repositeries.FormationDAO; // Changed from VideoDAO to FormationDAO
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FormationManagerService implements FormationManager { // Changed from VideoManagerService to FormationManagerService
    @Autowired
    private final FormationDAO formationRepo; // Changed from VideoDAO to FormationDAO


    public FormationManagerService(FormationDAO formationRepo) {
        this.formationRepo = formationRepo;
    }

    @Override
    public Formation addFormation(Formation formation) { // Changed from Video to Formation
        return formationRepo.save(formation);
    }

    @Override
    public Formation updateFormation(Formation formation) { // Changed from Video to Formation
        return formationRepo.save(formation);
    }

    @Override
    public boolean deleteFormation(long id) { // Changed from Video to Formation
        formationRepo.deleteById(id);
        return true;
    }
    @Override
    public Page<Formation> searchFormation(String keyword, int page, int taille){
        return formationRepo.findByNomFormationContains(keyword, PageRequest.of(page, taille));

    }
    @Override
    public List<Formation> getAllFormations() { // Changed from Video to Formation
        return formationRepo.findAll();
    }

    @Override
    public Formation getFormationById(long id) { // Changed from Video to Formation
        return formationRepo.findById(id).orElse(null);
    }

}
