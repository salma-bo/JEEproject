package ma.xproce.inventoryservice.service;

import ma.xproce.inventoryservice.dao.entities.CoutFormation;

import org.springframework.data.domain.Page;

import java.util.List;

public interface CoutFormationManager {
    public CoutFormation addCoutFormation(CoutFormation coutFormation);
    public Page<CoutFormation> searchCoutFormation(String keyword, int page, int taille);
    public CoutFormation updateCoutFormation(CoutFormation coutFormation);
    public boolean deleteCoutFormation(long id);
    public List<CoutFormation> getAllCoutFormation();

    public CoutFormation getCoutFormationById(long id);
}
