package ma.xproce.inventoryservice.dao.repositeries;

import ma.xproce.inventoryservice.dao.entities.Creator;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CreatorDAO extends JpaRepository<Creator, Long>{
    Page<Creator> findByNameContains(String keyword, Pageable pageable);
    public Optional<Creator> findByName(String username);
}
