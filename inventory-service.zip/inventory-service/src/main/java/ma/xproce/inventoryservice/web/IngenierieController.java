package ma.xproce.inventoryservice.web;

import ma.xproce.inventoryservice.dao.entities.Ingenierie;
import ma.xproce.inventoryservice.service.IngenierieManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;

@Controller
public class IngenierieController {
    @Autowired
    IngenierieManagerService ingenierieManagerService;

    @GetMapping("/deleteIngenierie")
    public String deleteFormationAction(@RequestParam(name = "id") Integer id) {
        Ingenierie ingenierieToDelete = ingenierieManagerService.getIngenierieById(id);
        boolean deletionResult = ingenierieManagerService.deleteIngenierie(id);

        if (deletionResult) {
            return "redirect:/Ing";
        } else {
            return "error";
        }
    }

    @GetMapping("/editIngenierie")
    public String editIngenierieForm(Model m, @RequestParam(name = "id") Integer id) {
        Ingenierie ingenierie = ingenierieManagerService.getIngenierieById(id);
        if (ingenierie != null) {
            m.addAttribute("ingenierieToBeUpdated", ingenierie);
            return "updateingenierie";
        } else {
            return "error";
        }
    }

    @PostMapping("/editIngenierie")
    public String updateIngenierie(Model model,
                                   @RequestParam(name = "id") Integer id,
                                   @RequestParam(name = "domaineFormation") String domaineFormation,
                                   @RequestParam(name = "theme") String theme,
                                   @RequestParam(name = "objectif") String objectif,
                                   @RequestParam(name = "contenu") String contenu,
                                   @RequestParam(name = "cadres") int cadres,
                                   @RequestParam(name = "employes") int employes,
                                   @RequestParam(name = "ouvrier") int ouvrier,
                                   @RequestParam(name = "coutFormation") int coutFormation,
                                   @RequestParam(name = "dateDebut") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateDebut,
                                   @RequestParam(name = "dateFin") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateFin,
                                   @RequestParam(name = "nomEntreprise") String nomEntreprise) {
        Ingenierie ingenierieToUpdate = ingenierieManagerService.getIngenierieById(id);
        if (ingenierieToUpdate != null) {
            ingenierieToUpdate.setDomaineFormation(domaineFormation);
            ingenierieToUpdate.setTheme(theme);
            ingenierieToUpdate.setObjectif(objectif);
            ingenierieToUpdate.setContenu(contenu);
            ingenierieToUpdate.setCadres(cadres);
            ingenierieToUpdate.setEmployes(employes);
            ingenierieToUpdate.setOuvrier(ouvrier);
            ingenierieToUpdate.setCoutFormation(coutFormation);
            ingenierieToUpdate.setDateDebut(dateDebut);
            ingenierieToUpdate.setDateFin(dateFin);
            ingenierieToUpdate.setNomEntreprise(nomEntreprise);
            ingenierieManagerService.updateIngenierie(ingenierieToUpdate);
            return "redirect:/Ing";
        } else {
            return "error";
        }
    }

    @GetMapping("/ajoutIngenierie")
    public String addIngenierieForm() {
        return "ajoutIngenierie";
    }

    @PostMapping("/ajoutIngenierie")
    public String addIngenierie(Model model,
                                @RequestParam(name = "id") Integer id,
                                @RequestParam(name = "domaineFormation") String domaineFormation,
                                @RequestParam(name = "theme") String theme,
                                @RequestParam(name = "objectif") String objectif,
                                @RequestParam(name = "contenu") String contenu,
                                @RequestParam(name = "cadres") int cadres,
                                @RequestParam(name = "employes") int employes,
                                @RequestParam(name = "ouvrier") int ouvrier,
                                @RequestParam(name = "coutFormation") int coutFormation,
                                @RequestParam(name = "dateDebut") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateDebut,
                                @RequestParam(name = "dateFin") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateFin,
                                @RequestParam(name = "nomEntreprise") String nomEntreprise) {
        Ingenierie ingenierie = new Ingenierie();

        ingenierie.setDomaineFormation(domaineFormation);
        ingenierie.setTheme(theme);
        ingenierie.setObjectif(objectif);
        ingenierie.setContenu(contenu);
        ingenierie.setCadres(cadres);
        ingenierie.setEmployes(employes);
        ingenierie.setOuvrier(ouvrier);
        ingenierie.setCoutFormation(coutFormation);
        ingenierie.setDateDebut(dateDebut);
        ingenierie.setDateFin(dateFin);
        ingenierie.setNomEntreprise(nomEntreprise);
        ingenierieManagerService.addIngenierie(ingenierie);

        return "redirect:/Ing";
    }

    @GetMapping("/Ing")
    public String listIngenieries(Model m,
                                  @RequestParam(name = "page", defaultValue = "0") int page,
                                  @RequestParam(name = "taille", defaultValue = "3") int taille,
                                  @RequestParam(name = "search", defaultValue = "") String search) {
        Page<Ingenierie> ingenieries = ingenierieManagerService.searchIngenierie(search, page, taille);
        m.addAttribute("listIngenierie", ingenieries.getContent());
        m.addAttribute("pages", new int[ingenieries.getTotalPages()]);
        m.addAttribute("currentPage", page);
        m.addAttribute("search", search);
        return "indexIngenierie";
    }
}
