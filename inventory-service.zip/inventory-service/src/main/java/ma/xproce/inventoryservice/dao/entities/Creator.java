package ma.xproce.inventoryservice.dao.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.Collection;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class Creator {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String name;
    private String mail;
    private String password;
    private String role;

    @OneToMany(mappedBy = "creator", fetch = FetchType.EAGER) // Changed from "creat" to "creator"
    private Collection<Formation> formations; // Changed from "vid" to "formations"

    public void addFormation(Formation newFormation) { // Changed from addVideo to addFormation
        if (this.formations == null) {
            this.formations = new ArrayList<>();
        }
        this.formations.add(newFormation); // Changed from vid to formations
    }

    @Override
    public String toString() {
        return "Creator{" +
                "id=" + id +
                ", name=" + name +
                ", mail=" + mail +
                ", password= "+password+
                ", formations=" + formations + // Changed from vid to formations
                '}';
    }
}
