package ma.xproce.inventoryservice.dao.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class Ingenierie {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String domaineFormation;
    private String theme;
    private String objectif;
    private String contenu;
    private String nomEntreprise;

    private int cadres;
    private int employes;
    private int ouvrier;

    private int coutFormation;

    private LocalDate dateDebut;
    private LocalDate dateFin;

    private static int numFormation =0; // New field for "numFormation"



    public Ingenierie( long id, String domaineFormation, String theme, String objectif, String contenu, String nomEntreprise, int cadres, int employes, int ouvrier,
                       int coutFormation, LocalDate dateDebut, LocalDate dateFin,Creator creator) {
        this.domaineFormation = domaineFormation;
        this.theme = theme;
        this.objectif = objectif;
        this.contenu = contenu;
        this.nomEntreprise = nomEntreprise;
        this.cadres = cadres;
        this.employes = employes;
        this.ouvrier = ouvrier;
        this.coutFormation = coutFormation;

        numFormation++; // Assuming numFormation is a static variable tracking the number of formations
    }
    @Override
    public String toString() {
        return "Ingenierie{" +
                "id=" + id +
                ", domaine de formation='" + domaineFormation + '\'' +
                ", theme de l'action='" + theme + '\'' +
                ", objectif(compétences visé)='" + objectif + '\'' +
                ", contenu indicatif='" + contenu + '\'' +
                ", nom de l'Entreprise='" + nomEntreprise + '\'' +
                ", nombres des cadres='" + cadres + '\'' +
                ", nombres des employes='" + employes + '\'' +
                ", nombres des ouvrier='" + ouvrier + '\'' +
                ", cout formation='" + coutFormation + '\'' +

                ", dateDebut=" + dateDebut +
                ", dateFin=" + dateFin +

                ", numFormation='" + numFormation + '\'' +
                '}';
    }

}
