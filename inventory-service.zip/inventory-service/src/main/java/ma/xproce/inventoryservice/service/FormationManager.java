package ma.xproce.inventoryservice.service;

import ma.xproce.inventoryservice.dao.entities.Formation; // Changed from Video to Formation
import org.springframework.data.domain.Page;

import java.util.List;

public interface FormationManager {
    public Formation addFormation(Formation formation);
    public Page<Formation> searchFormation(String keyword, int page, int taille);
    public Formation updateFormation(Formation formation);
    public boolean deleteFormation(long id);
    public List<Formation> getAllFormations();

    public Formation getFormationById(long id);
}
