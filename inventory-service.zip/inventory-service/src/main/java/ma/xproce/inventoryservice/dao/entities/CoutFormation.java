package ma.xproce.inventoryservice.dao.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class CoutFormation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String themeAction;
    private int effectif;
    private int nbrGrpe;
    private int duree;
    private String prestataire;
    private int coutEstimJ;
    private int coutEstimT;



    @Override
    public String toString() {
        return "CoutFormation{" +
                "id=" + id +
                ", themeAction='" + themeAction + '\'' +
                ", effectif=" + effectif +
                ", nbrGrpe=" + nbrGrpe +
                ", duree=" + duree +
                ", prestataire='" + prestataire + '\'' +
                ", coutEstimJ=" + coutEstimJ +
                ", coutEstimT=" + coutEstimT +
                '}';
    }
}
